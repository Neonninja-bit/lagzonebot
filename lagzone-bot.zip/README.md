
# LagZone Bot

This is a simple Discord bot built with discord.py.

## Commands
- `!ping` - Replies with Pong!

## Setup
Make sure to install the dependencies from `requirements.txt` and replace `"YOUR_BOT_TOKEN"` in `main.py` with your actual bot token.
